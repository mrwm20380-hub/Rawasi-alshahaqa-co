import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart';

const brandRed = Color(0xFFE30613);
const brandNavy = Color(0xFF0D1B2A);
const brandBlack = Color(0xFF111111);
const pageBg = Color(0xFFF5F6F8);
const muted = Color(0xFF667085);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  String? startupError;
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) {
    startupError = e.toString();
  }
  runApp(RawasiApp(startupError: startupError));
}

class RawasiApp extends StatelessWidget {
  final String? startupError;
  const RawasiApp({super.key, this.startupError});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'رواسي الشاهقة',
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: pageBg,
          colorScheme: ColorScheme.fromSeed(seedColor: brandRed),
          cardTheme: CardThemeData(
            elevation: 3,
            margin: EdgeInsets.zero,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
          filledButtonTheme: FilledButtonThemeData(
            style: FilledButton.styleFrom(
              backgroundColor: brandRed,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              minimumSize: const Size.fromHeight(52),
            ),
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: brandNavy,
            foregroundColor: Colors.white,
            elevation: 0,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: Color(0xFFD0D5DD)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: brandRed, width: 1.5),
            ),
          ),
        ),
        home: Directionality(
          textDirection: TextDirection.rtl,
          child: AuthGate(startupError: startupError),
        ),
      );
}

class AuthGate extends StatelessWidget {
  final String? startupError;
  const AuthGate({super.key, this.startupError});

  @override
  Widget build(BuildContext context) {
    if (startupError != null) return LoginPage(startupError: startupError);
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator(color: brandRed)));
        }
        final user = snapshot.data;
        if (user == null) return const LoginPage();
        return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          future: FirebaseFirestore.instance.collection('users').doc(user.uid).get(),
          builder: (context, userSnapshot) {
            if (userSnapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator(color: brandRed)));
            }
            if (userSnapshot.hasError) {
              return LoginPage(startupError: userSnapshot.error.toString());
            }
            final data = userSnapshot.data?.data();
            if (data?['active'] == false) {
              FirebaseAuth.instance.signOut();
              return const LoginPage();
            }
            final role = data?['role'];
            if (role == 'admin') return const AdminHome();
            if (role == 'supervisor') return const SupervisorHome();
            if (role == 'driver') return const DriverHome();
            FirebaseAuth.instance.signOut();
            return const LoginPage();
          },
        );
      },
    );
  }
}

class BrandAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  const BrandAppBar({super.key, required this.title});
  @override
  Size get preferredSize => const Size.fromHeight(70);
  @override
  Widget build(BuildContext context) => AppBar(
        toolbarHeight: 70,
        backgroundColor: brandNavy,
        leadingWidth: 62,
        leading: Padding(
          padding: const EdgeInsets.all(8),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.asset('assets/rawasi_emblem_clean.png', fit: BoxFit.contain),
          ),
        ),
        titleSpacing: 4,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('رواسي الشاهقة للخدمات اللوجستية', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
            Text(title, style: const TextStyle(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class BrandLogo extends StatelessWidget {
  final double width;
  const BrandLogo({super.key, this.width = 250});
  @override
  Widget build(BuildContext context) => Container(
    width: width,
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: brandNavy,
      borderRadius: BorderRadius.circular(22),
      boxShadow: const [BoxShadow(blurRadius: 18, offset: Offset(0, 8), color: Color(0x22000000))],
    ),
    child: Image.asset('assets/rawasi_brand_lockup.png', fit: BoxFit.contain),
  );
}

class LoginPage extends StatefulWidget {
  final String? startupError;
  const LoginPage({super.key, this.startupError});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  bool obscure = true;
  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      _msg('أدخل البريد الإلكتروني وكلمة المرور');
      return;
    }
    setState(() => loading = true);
    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.text.trim(),
        password: password.text,
      );
      if (!mounted) return;
      await openUserHome(context, cred.user!);
    } on FirebaseAuthException catch (e) {
      _msg(authMessage(e.code));
    } catch (e) {
      _msg('تعذر تسجيل الدخول: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }


  void _msg(String s) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [brandNavy, Color(0xFF102A43), pageBg],
              stops: [0.0, 0.43, 0.78],
            ),
          ),
          child: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 28, 18, 28),
              children: [
                const SizedBox(height: 8),
                Center(child: BrandLogo(width: 285)),
                const SizedBox(height: 26),
                Card(
                  elevation: 8,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 22),
                    child: Column(
                      children: [
                        Container(
                          width: 58, height: 58,
                          decoration: BoxDecoration(color: brandRed.withOpacity(.10), shape: BoxShape.circle),
                          child: const Icon(Icons.lock_person_outlined, color: brandRed, size: 30),
                        ),
                        const SizedBox(height: 12),
                        const Text('تسجيل الدخول', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: brandNavy)),
                        const SizedBox(height: 5),
                        const Text('إدارة أسطول النقل والصيانة', style: TextStyle(color: muted, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 20),
                        TextField(
                          controller: email,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined)),
                        ),
                        const SizedBox(height: 13),
                        TextField(
                          controller: password,
                          obscureText: obscure,
                          decoration: InputDecoration(
                            labelText: 'كلمة المرور',
                            prefixIcon: const Icon(Icons.lock_outline),
                            suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined)),
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity, height: 54,
                          child: FilledButton.icon(
                            onPressed: loading ? null : login,
                            icon: loading ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Icon(Icons.login),
                            label: Text(loading ? 'جاري الدخول...' : 'دخول آمن', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Center(child: Text('رواسي الشاهقة للخدمات اللوجستية', style: TextStyle(color: brandNavy, fontWeight: FontWeight.w900))),
                if (widget.startupError != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 15),
                    child: Text('تعذر تهيئة Firebase: ${widget.startupError}', textAlign: TextAlign.center, style: const TextStyle(color: brandRed)),
                  ),
              ],
            ),
          ),
        ),
      );

}

String authMessage(String code) => switch (code) {
      'invalid-credential' || 'wrong-password' || 'user-not-found' =>
        'البريد أو كلمة المرور غير صحيحة',
      'email-already-in-use' => 'البريد مستخدم مسبقًا',
      'invalid-email' => 'البريد الإلكتروني غير صحيح',
      'weak-password' => 'كلمة المرور ضعيفة',
      'network-request-failed' => 'تحقق من اتصال الإنترنت',
      'operation-not-allowed' => 'طريقة تسجيل الدخول بالبريد غير مفعلة في Firebase',
      _ => 'تعذر تسجيل الدخول: $code'
    };

Future<void> openUserHome(BuildContext context, User user) async {
  try {
    final snap = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    if (!context.mounted) return;
    final data = snap.data();
    final role = data?['role'];
    if (data?['active'] == false) {
      await FirebaseAuth.instance.signOut();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هذا الحساب غير مفعل. تواصل مع المدير.')));
      }
      return;
    }
    if (role == 'admin') {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AdminHome()));
      return;
    }
    if (role == 'supervisor') {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SupervisorHome()));
      return;
    }
    if (role == 'driver') {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DriverHome()));
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('هذا الحساب غير مفعّل. تواصل مع إدارة رواسي الشاهقة.'),
    ));
  } on FirebaseException catch (e) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(e.code == 'permission-denied'
          ? 'لا توجد صلاحية لقراءة نوع الحساب. راجع قواعد Firestore.'
          : 'تعذر التعرف على صلاحية الحساب: ${e.message ?? e.code}'),
    ));
  }
}


String statusOf(Map<String, dynamic> d) => '${d['status'] ?? 'جديد'}';
bool isProcessedStatus(String status) => status == 'تم الإصلاح' || status == 'مغلق';

class VehicleFormPage extends StatefulWidget {
  final String? vehicleId;
  final Map<String, dynamic>? initial;
  const VehicleFormPage({super.key, this.vehicleId, this.initial});
  @override State<VehicleFormPage> createState() => _VehicleFormPageState();
}

class _VehicleFormPageState extends State<VehicleFormPage> {
  final name = TextEditingController();
  final truckPlate = TextEditingController();
  final trailerPlate = TextEditingController();
  final lastOil = TextEditingController();
  bool saving = false;
  @override void initState() { super.initState(); final d=widget.initial ?? {}; name.text='${d['name'] ?? ''}'; truckPlate.text='${d['truckPlate'] ?? ''}'; trailerPlate.text='${d['trailerPlate'] ?? ''}'; lastOil.text='${d['lastOilOdometer'] ?? ''}'; }
  @override void dispose(){name.dispose();truckPlate.dispose();trailerPlate.dispose();lastOil.dispose();super.dispose();}
  Future<void> save() async {
    final n=name.text.trim(), tp=truckPlate.text.trim(), tr=trailerPlate.text.trim();
    final lo=int.tryParse(lastOil.text.trim());
    if(n.isEmpty || tp.isEmpty || lo==null || lo<0){_msg('أدخل اسم الشاحنة ولوحة الشاحنة وعداد آخر غيار زيت بشكل صحيح');return;}
    setState(()=>saving=true);
    try{
      final ref=widget.vehicleId==null?FirebaseFirestore.instance.collection('vehicles').doc():FirebaseFirestore.instance.collection('vehicles').doc(widget.vehicleId);
      final old=widget.initial ?? {};
      final data=<String,dynamic>{'name':n,'truckPlate':tp,'trailerPlate':tr,'lastOilOdometer':lo,'nextOilOdometer':lo+15000,'updatedAt':FieldValue.serverTimestamp()};
      if(widget.vehicleId==null){data['createdAt']=FieldValue.serverTimestamp();data['history']=<Map<String,dynamic>>[];} else {data['history']=old['history'] ?? <Map<String,dynamic>>[];}
      await ref.set(data, SetOptions(merge:true));
      if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ ملف المركبة')));Navigator.pop(context,true);}
    }on FirebaseException catch(e){_msg('تعذر حفظ المركبة: ${e.message ?? e.code}');}finally{if(mounted)setState(()=>saving=false);}
  }
  void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
  @override Widget build(BuildContext c)=>Scaffold(appBar: BrandAppBar(title:widget.vehicleId==null?'إضافة مركبة':'تعديل ملف المركبة'),body:ListView(padding:const EdgeInsets.all(18),children:[Center(child:BrandLogo(width:190)),const SizedBox(height:15),TextField(controller:name,decoration:const InputDecoration(labelText:'اسم الشاحنة / المركبة',prefixIcon:Icon(Icons.local_shipping_outlined))),const SizedBox(height:12),TextField(controller:truckPlate,decoration:const InputDecoration(labelText:'لوحة الشاحنة',prefixIcon:Icon(Icons.badge_outlined))),const SizedBox(height:12),TextField(controller:trailerPlate,decoration:const InputDecoration(labelText:'لوحة المركبة / المقطورة',prefixIcon:Icon(Icons.confirmation_number_outlined))),const SizedBox(height:12),TextField(controller:lastOil,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'عداد آخر غيار زيت (كم)',prefixIcon:Icon(Icons.speed))),const SizedBox(height:8),const Text('غيار الزيت القادم يُحسب تلقائيًا بعد 15,000 كم.',style:TextStyle(color:muted)),const SizedBox(height:24),SizedBox(height:54,child:FilledButton.icon(onPressed:saving?null:save,style:FilledButton.styleFrom(backgroundColor:brandRed),icon:saving?const SizedBox(width:18,height:18,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)):const Icon(Icons.save),label:Text(saving?'جاري الحفظ...':'حفظ ملف المركبة')))]));
}

class VehicleListPage extends StatefulWidget { const VehicleListPage({super.key}); @override State<VehicleListPage> createState()=>_VehicleListPageState(); }
class _VehicleListPageState extends State<VehicleListPage>{
  Future<void> deleteVehicle(String id) async { final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('حذف ملف المركبة؟'),content:const Text('سيتم حذف ملف المركبة فقط. سجلات البلاغات السابقة لن تُحذف.'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,true),style:FilledButton.styleFrom(backgroundColor:brandRed),child:const Text('حذف'))])); if(ok!=true)return; try{await FirebaseFirestore.instance.collection('vehicles').doc(id).delete();}on FirebaseException catch(e){_msg('تعذر الحذف: ${e.message ?? e.code}');} }
  void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
  @override Widget build(BuildContext c)=>Scaffold(appBar:BrandAppBar(title:'ملفات المركبات'),body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirebaseFirestore.instance.collection('vehicles').orderBy('name').snapshots(),builder:(ctx,s){if(s.hasError)return ErrorBox(error:s.error.toString(),onRetry:()=>setState((){}));if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator(color:brandRed));final docs=s.data?.docs??[];return ListView(padding:const EdgeInsets.fromLTRB(18,18,18,100),children:[SizedBox(height:52,child:FilledButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const VehicleFormPage())),style:FilledButton.styleFrom(backgroundColor:brandRed),icon:const Icon(Icons.add),label:const Text('إضافة ملف مركبة',style:TextStyle(fontWeight:FontWeight.w900)))),const SizedBox(height:18),if(docs.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(30),child:Center(child:Text('لا توجد ملفات مركبات')))) else ...docs.map((d)=>Card(child:ListTile(leading:const CircleAvatar(backgroundColor:brandNavy,child:Icon(Icons.local_shipping,color:Colors.white)),title:Text('${d.data()['name']??'مركبة'}',style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('لوحة الشاحنة: ${d.data()['truckPlate']??''}\nلوحة المقطورة: ${d.data()['trailerPlate']??''}\nزيت قادم: ${d.data()['nextOilOdometer']??'-'} كم'),isThreeLine:true,onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>VehicleDetailsPage(vehicleId:d.id)),),trailing:PopupMenuButton<String>(onSelected:(v){if(v=='edit')Navigator.push(c,MaterialPageRoute(builder:(_)=>VehicleFormPage(vehicleId:d.id,initial:d.data())));if(v=='delete')deleteVehicle(d.id);},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('تعديل')),PopupMenuItem(value:'delete',child:Text('حذف'))]))))]);}));
}

class StaticVehicle360Viewer extends StatefulWidget {
  const StaticVehicle360Viewer({super.key});
  @override
  State<StaticVehicle360Viewer> createState() => _StaticVehicle360ViewerState();
}

class _StaticVehicle360ViewerState extends State<StaticVehicle360Viewer> {
  final PageController _controller = PageController();
  int _index = 0;
  final List<String> _views = const [
    'assets/vehicle360/vehicle360_1.jpg',
    'assets/vehicle360/vehicle360_2.jpg',
    'assets/vehicle360/vehicle360_3.jpg',
    'assets/vehicle360/vehicle360_4.jpg',
    'assets/vehicle360/vehicle360_5.jpg',
  ];

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  void _go(int i) {
    final next = i.clamp(0, _views.length - 1);
    _controller.animateToPage(next, duration: const Duration(milliseconds: 280), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [brandNavy, Color(0xFF183B5F)]),
            ),
            child: Row(children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: brandRed, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.threesixty, color: Colors.white)),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('صور المركبة 360°', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                SizedBox(height: 3),
                Text('اسحب يمينًا أو يسارًا لمشاهدة جميع الزوايا', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w600)),
              ])),
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(20)), child: Text('${_index + 1}/${_views.length}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
            ]),
          ),
          SizedBox(
            height: 255,
            child: Stack(children: [
              PageView.builder(
                controller: _controller,
                itemCount: _views.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (_, i) => Padding(padding: const EdgeInsets.all(10), child: ClipRRect(borderRadius: BorderRadius.circular(15), child: Image.asset(_views[i], fit: BoxFit.cover))),
              ),
              Positioned(left: 12, top: 0, bottom: 0, child: Center(child: _navButton(Icons.chevron_left, () => _go(_index - 1)))),
              Positioned(right: 12, top: 0, bottom: 0, child: Center(child: _navButton(Icons.chevron_right, () => _go(_index + 1)))),
            ]),
          ),
          SizedBox(height: 74, child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            scrollDirection: Axis.horizontal,
            itemCount: _views.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) => GestureDetector(
              onTap: () => _go(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: 82,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: i == _index ? brandRed : Colors.transparent, width: 3)),
                child: ClipRRect(borderRadius: BorderRadius.circular(7), child: Image.asset(_views[i], fit: BoxFit.cover)),
              ),
            ),
          )),
        ],
      ),
    );
  }

  Widget _navButton(IconData icon, VoidCallback onTap) => Material(
    color: brandNavy.withOpacity(.82), shape: const CircleBorder(),
    child: InkWell(onTap: onTap, customBorder: const CircleBorder(), child: Padding(padding: const EdgeInsets.all(8), child: Icon(icon, color: Colors.white, size: 26))),
  );
}

class VehicleDetailsPage extends StatefulWidget {
  final String vehicleId;
  const VehicleDetailsPage({super.key, required this.vehicleId});
  @override
  State<VehicleDetailsPage> createState() => _VehicleDetailsPageState();
}

class _VehicleDetailsPageState extends State<VehicleDetailsPage> {
  Future<void> deleteHistoryItem(String id, Map<String, dynamic> vehicle) async {
    final list = List<Map<String, dynamic>>.from(
      (vehicle['history'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)),
    );
    list.removeWhere((e) => '${e['id'] ?? ''}' == id);
    try {
      await FirebaseFirestore.instance.collection('vehicles').doc(widget.vehicleId).update({'history': list});
    } on FirebaseException catch (e) {
      _msg('تعذر حذف السجل: ${e.message ?? e.code}');
    }
  }

  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const BrandAppBar(title: 'ملف المركبة'),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('vehicles').doc(widget.vehicleId).snapshots(),
        builder: (ctx, s) {
          if (s.hasError) return ErrorBox(error: s.error.toString(), onRetry: () => setState(() {}));
          if (!s.hasData || !s.data!.exists) return const Center(child: Text('ملف المركبة غير موجود'));
          final d = s.data!.data()!;
          final hist = List<Map<String, dynamic>>.from(
            (d['history'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)),
          );
          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Card(
                color: brandNavy,
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${d['name'] ?? ''}', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 8),
                      Text('لوحة الشاحنة: ${d['truckPlate'] ?? ''}', style: const TextStyle(color: Colors.white)),
                      Text('لوحة المقطورة: ${d['trailerPlate'] ?? ''}', style: const TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: StatCard(label: 'آخر غيار زيت', value: '${d['lastOilOdometer'] ?? '-'}', icon: Icons.oil_barrel, color: brandNavy)),
                  const SizedBox(width: 10),
                  Expanded(child: StatCard(label: 'الغيار القادم', value: '${d['nextOilOdometer'] ?? '-'}', icon: Icons.speed, color: brandRed)),
                ],
              ),
              const SizedBox(height: 18),
              const StaticVehicle360Viewer(),
              const SizedBox(height: 22),
              const Text('الأعطال والمعالجات السابقة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              if (hist.isEmpty)
                const Card(child: Padding(padding: EdgeInsets.all(25), child: Center(child: Text('لا توجد أعطال معالجة سابقة'))))
              else
                ...hist.reversed.map((h) {
                  final hid = '${h['id'] ?? ''}';
                  return Card(
                    child: ListTile(
                      title: Text('${h['fault'] ?? 'عطل'}', style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text('المعالجة: ${h['treatment'] ?? 'غير مسجلة'}\nالتاريخ: ${formatHistoryDate(h['date'])}'),
                      isThreeLine: true,
                      trailing: PopupMenuButton<String>(
                        onSelected: (v) async {
                          if (v == 'delete') await deleteHistoryItem(hid, d);
                        },
                        itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('حذف السجل'))],
                      ),
                    ),
                  );
                }),
              const SizedBox(height: 10),
              FilledButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VehicleFormPage(vehicleId: widget.vehicleId, initial: d))),
                style: FilledButton.styleFrom(backgroundColor: brandRed),
                icon: const Icon(Icons.edit),
                label: const Text('تعديل ملف المركبة'),
              ),
            ],
          );
        },
      ),
    );
  }
}

String formatHistoryDate(dynamic v){if(v is Timestamp)return '${v.toDate().day}/${v.toDate().month}/${v.toDate().year}';return '-';}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  Future<void> logout() async {
    await FirebaseAuth.instance.signOut();
    if (mounted) {
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: brandNavy,
          foregroundColor: Colors.white,
          title: const Text('إدارة الحسابات', style: TextStyle(fontWeight: FontWeight.w900)),
          leading: Padding(
            padding: const EdgeInsets.all(7),
            child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/rawasi_emblem_clean.png', fit: BoxFit.contain)),
          ),
          actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout))],
        ),
        body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('users').snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) return ErrorBox(error: snapshot.error.toString(), onRetry: () => setState(() {}));
            if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: brandRed));
            final docs = snapshot.data?.docs ?? [];
            return ListView(
              padding: const EdgeInsets.all(18),
              children: [
                Card(color: brandNavy, child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Row(children: [
                    const Icon(Icons.admin_panel_settings, color: Colors.white, size: 34),
                    const SizedBox(width: 12),
                    Expanded(child: Text('أنت تتحكم في حسابات السائقين والمشرفين', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900))),
                  ]),
                )),
                const SizedBox(height: 18),
                SizedBox(
                  height: 54,
                  child: FilledButton.icon(
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateUserPage())),
                    style: FilledButton.styleFrom(backgroundColor: brandRed),
                    icon: const Icon(Icons.person_add_alt_1),
                    label: const Text('إنشاء مستخدم جديد', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(height: 52, child: OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VehicleListPage())), icon: const Icon(Icons.local_shipping_outlined), label: const Text('إدارة ملفات المركبات', style: TextStyle(fontWeight: FontWeight.w900)))),
                const SizedBox(height: 22),
                const Text('المستخدمون', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                if (docs.isEmpty)
                  const Card(child: Padding(padding: EdgeInsets.all(28), child: Center(child: Text('لا يوجد مستخدمون'))))
                else
                  ...docs.map((d) {
                    final data = d.data();
                    final role = '${data['role'] ?? ''}';
                    final label = role == 'admin' ? 'مدير' : role == 'supervisor' ? 'مشرف' : role == 'driver' ? 'سائق' : 'غير محدد';
                    return Card(
                      child: ListTile(
                        leading: CircleAvatar(backgroundColor: role == 'driver' ? brandRed.withValues(alpha: .1) : brandNavy.withValues(alpha: .1), child: Icon(role == 'driver' ? Icons.local_shipping : Icons.dashboard, color: role == 'driver' ? brandRed : brandNavy)),
                        title: Text('${data['name'] ?? data['email'] ?? 'مستخدم'}', style: const TextStyle(fontWeight: FontWeight.w900)),
                        subtitle: Text('${data['email'] ?? ''}\n$label${data['vehicle'] != null && data['vehicle'] != '' ? ' • ${data['vehicle']}' : ''}${data['active'] == false ? ' • غير مفعل' : ''}'),
                        isThreeLine: true,
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) async {
                            if (v == 'edit') {
                              await Navigator.push(context, MaterialPageRoute(builder: (_) => EditUserPage(userId: d.id, initial: data)));
                            }
                          },
                          itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('تعديل المستخدم'))],
                        ),
                      ),
                    );
                  }),
              ],
            );
          },
        ),
      );
}


class EditUserPage extends StatefulWidget {
  final String userId;
  final Map<String, dynamic> initial;
  const EditUserPage({super.key, required this.userId, required this.initial});
  @override
  State<EditUserPage> createState() => _EditUserPageState();
}

class _EditUserPageState extends State<EditUserPage> {
  late final TextEditingController name;
  late final TextEditingController email;
  String role = 'driver';
  String? selectedVehicleId;
  String selectedVehicleName = '';
  List<QueryDocumentSnapshot<Map<String, dynamic>>> vehicleDocs = [];
  bool active = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: '${widget.initial['name'] ?? ''}');
    email = TextEditingController(text: '${widget.initial['email'] ?? ''}');
    role = '${widget.initial['role'] ?? 'driver'}';
    if (role != 'driver' && role != 'supervisor' && role != 'admin') role = 'driver';
    selectedVehicleId = widget.initial['vehicleId'] as String?;
    selectedVehicleName = '${widget.initial['vehicleName'] ?? widget.initial['vehicle'] ?? ''}';
    active = widget.initial['active'] != false;
    loadVehicles();
  }

  Future<void> loadVehicles() async {
    try {
      final s = await FirebaseFirestore.instance.collection('vehicles').orderBy('name').get();
      if (mounted) setState(() => vehicleDocs = s.docs);
    } catch (_) {}
  }

  @override
  void dispose() { name.dispose(); email.dispose(); super.dispose(); }

  Future<void> save() async {
    if (name.text.trim().isEmpty || email.text.trim().isEmpty) {
      _msg('أدخل اسم المستخدم والبريد الإلكتروني');
      return;
    }
    if (role == 'driver' && selectedVehicleId == null) {
      _msg('اختر المركبة المخصصة للسائق');
      return;
    }
    setState(() => saving = true);
    try {
      await FirebaseFirestore.instance.collection('users').doc(widget.userId).update({
        'name': name.text.trim(),
        // Email here is the profile email. Changing the Firebase Auth sign-in email
        // requires a privileged backend/Admin SDK and is intentionally not faked here.
        'email': email.text.trim(),
        'role': role,
        'vehicleId': role == 'driver' ? (selectedVehicleId ?? '') : '',
        'vehicleName': role == 'driver' ? selectedVehicleName : '',
        'vehicle': role == 'driver' ? selectedVehicleName : '',
        'active': active,
        'updatedAt': FieldValue.serverTimestamp(),
        'updatedBy': FirebaseAuth.instance.currentUser?.uid,
      });
      if (!mounted) return;
      Navigator.pop(context, true);
    } on FirebaseException catch (e) {
      _msg('تعذر تعديل المستخدم: ${e.message ?? e.code}');
    } catch (e) {
      _msg('حدث خطأ: $e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> sendResetEmail() async {
    final e = email.text.trim();
    if (e.isEmpty) { _msg('لا يوجد بريد إلكتروني'); return; }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: e);
      _msg('تم إرسال رابط إعادة تعيين كلمة المرور');
    } on FirebaseAuthException catch (e) {
      _msg(authMessage(e.code));
    }
  }

  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: const BrandAppBar(title: 'تعديل المستخدم'),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Center(child: BrandLogo(width: 210)),
        const SizedBox(height: 14),
        const Text('تعديل بيانات المستخدم وتخصيص المركبة', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 20),
        TextField(controller: name, enabled: !saving, decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline))),
        const SizedBox(height: 12),
        TextField(controller: email, enabled: !saving, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني في الملف', prefixIcon: Icon(Icons.email_outlined))),
        const SizedBox(height: 14),
        const Label('نوع المستخدم'),
        DropdownButtonFormField<String>(
          value: role,
          items: const [
            DropdownMenuItem(value: 'driver', child: Text('سائق')),
            DropdownMenuItem(value: 'supervisor', child: Text('مشرف')),
            DropdownMenuItem(value: 'admin', child: Text('مدير')),
          ],
          onChanged: saving ? null : (v) => setState(() => role = v ?? role),
        ),
        if (role == 'driver') ...[
          const SizedBox(height: 14),
          const Label('المركبة المخصصة'),
          DropdownButtonFormField<String>(
            value: vehicleDocs.any((d) => d.id == selectedVehicleId) ? selectedVehicleId : null,
            items: vehicleDocs.map((d) {
              final dta = d.data();
              return DropdownMenuItem<String>(value: d.id, child: Text('${dta['name'] ?? 'مركبة'} • ${dta['truckPlate'] ?? ''}'));
            }).toList(),
            onChanged: saving ? null : (v) {
              final matches = vehicleDocs.where((d) => d.id == v);
              final match = matches.isEmpty ? null : matches.first;
              setState(() { selectedVehicleId = v; selectedVehicleName = match == null ? '' : '${match.data()['name'] ?? 'مركبة'}'; });
            },
            hint: const Text('اختر المركبة'),
          ),
        ],
        const SizedBox(height: 14),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('الحساب مفعل', style: TextStyle(fontWeight: FontWeight.w800)),
          subtitle: const Text('إيقافه يمنع استخدام الحساب داخل التطبيق'),
          value: active,
          onChanged: saving ? null : (v) => setState(() => active = v),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: saving ? null : sendResetEmail, icon: const Icon(Icons.lock_reset), label: const Text('إرسال رابط إعادة تعيين كلمة المرور')),
        const SizedBox(height: 18),
        SizedBox(height: 54, child: FilledButton.icon(
          onPressed: saving ? null : save,
          style: FilledButton.styleFrom(backgroundColor: brandRed),
          icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Icon(Icons.save),
          label: Text(saving ? 'جاري الحفظ...' : 'حفظ التعديلات', style: const TextStyle(fontWeight: FontWeight.w900)),
        )),
      ],
    ),
  );
}

class CreateUserPage extends StatefulWidget {
  const CreateUserPage({super.key});
  @override
  State<CreateUserPage> createState() => _CreateUserPageState();
}

class _CreateUserPageState extends State<CreateUserPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final vehicle = TextEditingController();
  String role = 'driver';
  String? selectedVehicleId;
  String selectedVehicleName = '';
  List<QueryDocumentSnapshot<Map<String, dynamic>>> vehicleDocs = [];
  bool saving = false;
  bool obscure = true;

  @override
  void initState() { super.initState(); loadVehicles(); }

  Future<void> loadVehicles() async {
    try {
      final s = await FirebaseFirestore.instance.collection('vehicles').orderBy('name').get();
      if (mounted) setState(() => vehicleDocs = s.docs);
    } catch (_) {}
  }

  @override
  void dispose() { name.dispose(); email.dispose(); password.dispose(); vehicle.dispose(); super.dispose(); }

  Future<void> createUser() async {
    final e = email.text.trim();
    final p = password.text;
    if (name.text.trim().isEmpty || e.isEmpty || p.length < 6) {
      _msg('أدخل اسم المستخدم والبريد وكلمة مرور من 6 أحرف على الأقل');
      return;
    }
    if (role == 'driver' && (selectedVehicleId == null || selectedVehicleName.trim().isEmpty)) {
      _msg('اختر المركبة التي سيتم تخصيصها لهذا السائق');
      return;
    }
    setState(() => saving = true);
    FirebaseApp? secondary;
    try {
      secondary = await Firebase.initializeApp(name: 'accountCreator', options: DefaultFirebaseOptions.currentPlatform);
      final secondaryAuth = FirebaseAuth.instanceFor(app: secondary);
      final cred = await secondaryAuth.createUserWithEmailAndPassword(email: e, password: p);
      await FirebaseFirestore.instance.collection('users').doc(cred.user!.uid).set({
        'uid': cred.user!.uid,
        'name': name.text.trim(),
        'email': e,
        'role': role,
        'vehicleId': role == 'driver' ? (selectedVehicleId ?? '') : '',
        'vehicleName': role == 'driver' ? selectedVehicleName : '',
        'vehicle': role == 'driver' ? (selectedVehicleName.isNotEmpty ? selectedVehicleName : vehicle.text.trim()) : '',
        'createdAt': FieldValue.serverTimestamp(),
        'createdBy': FirebaseAuth.instance.currentUser!.uid,
      });
      await secondaryAuth.signOut();
      if (!mounted) return;
      _msg('تم إنشاء الحساب وتوزيعه بنجاح');
      name.clear(); email.clear(); password.clear(); vehicle.clear();
    } on FirebaseAuthException catch (e) {
      _msg(authMessage(e.code));
    } on FirebaseException catch (e) {
      _msg('تعذر حفظ بيانات المستخدم: ${e.message ?? e.code}');
    } catch (e) {
      _msg('حدث خطأ: $e');
    } finally {
      if (secondary != null) {
        try { await Firebase.app('accountCreator').delete(); } catch (_) {}
      }
      if (mounted) setState(() => saving = false);
    }
  }

  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: const BrandAppBar(title: 'إنشاء مستخدم'),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Center(child: BrandLogo(width: 220)),
            const SizedBox(height: 12),
            const Text('هذه الصفحة للمدير فقط — كل حساب سائق يُربط بمركبة واحدة', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 20),
            TextField(controller: name, enabled: !saving, decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline))),
            const SizedBox(height: 12),
            TextField(controller: email, enabled: !saving, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined))),
            const SizedBox(height: 12),
            TextField(controller: password, enabled: !saving, obscureText: obscure, decoration: InputDecoration(labelText: 'كلمة المرور المؤقتة', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility : Icons.visibility_off)))),
            const SizedBox(height: 14),
            const Label('نوع المستخدم'),
            DropdownButtonFormField<String>(
              value: role,
              items: const [DropdownMenuItem(value: 'driver', child: Text('سائق')), DropdownMenuItem(value: 'supervisor', child: Text('مشرف'))],
              onChanged: saving ? null : (v) => setState(() => role = v ?? role),
            ),
            if (role == 'driver') ...[
              const SizedBox(height: 14),
              const Label('المركبة المخصصة'),
              DropdownButtonFormField<String>(
                value: selectedVehicleId,
                items: vehicleDocs.map((d) {
                  final dta = d.data();
                  return DropdownMenuItem<String>(value: d.id, child: Text('${dta['name'] ?? 'مركبة'} • ${dta['truckPlate'] ?? ''}'));
                }).toList(),
                onChanged: saving ? null : (v) {
                  final matches = vehicleDocs.where((d) => d.id == v);
                  final match = matches.isEmpty ? null : matches.first;
                  setState(() { selectedVehicleId = v; selectedVehicleName = match == null ? '' : '${match.data()['name'] ?? 'مركبة'}'; });
                },
                hint: Text(vehicleDocs.isEmpty ? 'لا توجد مركبات بعد — يمكن التعيين لاحقًا' : 'اختر المركبة'),
              ),
              if (vehicleDocs.isEmpty) ...[
                const SizedBox(height: 8),
                TextField(controller: vehicle, enabled: !saving, decoration: const InputDecoration(labelText: 'اسم المركبة (اختياري)', prefixIcon: Icon(Icons.local_shipping_outlined))),
              ],
            ],
            const SizedBox(height: 24),
            SizedBox(height: 54, child: FilledButton.icon(
              onPressed: saving ? null : createUser,
              style: FilledButton.styleFrom(backgroundColor: brandRed),
              icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Icon(Icons.person_add),
              label: Text(saving ? 'جاري إنشاء الحساب...' : 'إنشاء الحساب', style: const TextStyle(fontWeight: FontWeight.w900)),
            )),
          ],
        ),
      );

}

class DriverHome extends StatefulWidget { const DriverHome({super.key}); @override State<DriverHome> createState()=>_DriverHomeState(); }
class _DriverHomeState extends State<DriverHome>{
  Map<String,dynamic>? profile; bool loadingProfile=true;
  @override void initState(){super.initState();loadProfile();}
  Future<void> loadProfile() async {final u=FirebaseAuth.instance.currentUser;if(u==null){return;}try{final s=await FirebaseFirestore.instance.collection('users').doc(u.uid).get();if(mounted)setState(()=>profile=s.data());}finally{if(mounted)setState(()=>loadingProfile=false);}}
  Future<void> logout() async {await FirebaseAuth.instance.signOut();if(mounted)Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const LoginPage()),(_)=>false);}
  @override Widget build(BuildContext context){final uid=FirebaseAuth.instance.currentUser?.uid;final vehicleId='${profile?['vehicleId'] ?? ''}'.trim();final vehicle='${profile?['vehicleName'] ?? profile?['vehicle'] ?? ''}'.trim();final hasVehicle=vehicleId.isNotEmpty && vehicle.isNotEmpty;return Scaffold(appBar:AppBar(backgroundColor:brandNavy,foregroundColor:Colors.white,title:const Text('تطبيق السائق',style:TextStyle(fontWeight:FontWeight.w900)),leading:Padding(padding:const EdgeInsets.all(7),child:ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.asset('assets/rawasi_emblem_clean.png',fit:BoxFit.cover))),actions:[IconButton(onPressed:logout,icon:const Icon(Icons.logout))]),body:loadingProfile?const Center(child:CircularProgressIndicator(color:brandRed)):StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:uid==null?null:FirebaseFirestore.instance.collection('faults').where('driverId',isEqualTo:uid).snapshots(),builder:(c,s){if(s.hasError)return ErrorBox(error:s.error.toString(),onRetry:()=>setState((){}));final docs=(s.data?.docs??[]).where((d)=>!isProcessedStatus(statusOf(d.data()))).toList()..sort((a,b)=>dateOf(b.data()).compareTo(dateOf(a.data())));return ListView(padding:const EdgeInsets.fromLTRB(18,18,18,110),children:[Container(
  padding: const EdgeInsets.all(18),
  decoration: BoxDecoration(color: brandNavy, borderRadius: BorderRadius.circular(22)),
  child: Row(
    children: [
      const Icon(Icons.local_shipping_rounded, color: Colors.white, size: 34),
      const SizedBox(width: 14),
      Expanded(
        child: Text(
          hasVehicle ? 'مركبتك: $vehicle' : 'لم يتم تخصيص مركبة لهذا الحساب',
          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
        ),
      ),
    ],
  ),
),
const SizedBox(height: 22),const Text('البلاغات المفتوحة',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:10),if(docs.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(35),child:Center(child:Text('لا توجد بلاغات مفتوحة')))) else ...docs.map((d)=>InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReportDetailsPage(report:d.data()))),child:ReportCard(report:d.data())))]);}),floatingActionButton: FloatingActionButton.extended(
  backgroundColor: hasVehicle ? brandRed : Colors.grey,
  foregroundColor: Colors.white,
  onPressed: hasVehicle
      ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddReportPage()))
      : () => ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('لا يمكن إرسال بلاغ قبل تخصيص مركبة لهذا المستخدم من المدير')),
        ),
  icon: const Icon(Icons.assignment_add),
  label: const Text('إضافة بلاغ'),
));}
}

class AddReportPage extends StatefulWidget {
  const AddReportPage({super.key});
  @override
  State<AddReportPage> createState() => _AddReportPageState();
}

class _AddReportPageState extends State<AddReportPage> {
  final desc = TextEditingController();
  final picker = ImagePicker();
  final photos = <XFile>[];
  String type = 'فرامل', severity = 'عادي';
  bool sending = false;
  @override
  void dispose() { desc.dispose(); super.dispose(); }

  Future<void> takePhoto() async {
    try {
      final p = await picker.pickImage(source: ImageSource.camera, imageQuality: 82);
      if (p != null && mounted) setState(() => photos.add(p));
    } catch (e) {
      if (mounted) _msg('تعذر فتح الكاميرا: $e');
    }
  }

  Future<void> submit() async {
    if (photos.isEmpty) { _msg('يجب تصوير العطل قبل إرسال البلاغ'); return; }
    if (desc.text.trim().isEmpty) { _msg('اكتب وصف العطل أولاً'); return; }
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) { _msg('انتهت جلسة الدخول، سجل الدخول مرة أخرى'); return; }
    setState(() => sending = true);
    DocumentReference<Map<String, dynamic>>? doc;
    try {
      doc = FirebaseFirestore.instance.collection('faults').doc();
      final userSnap = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final userData = userSnap.data() ?? <String,dynamic>{};
      final assignedVehicleId = '${userData['vehicleId'] ?? ''}'.trim();
      final assignedVehicleName = '${userData['vehicleName'] ?? userData['vehicle'] ?? ''}'.trim();
      if (assignedVehicleId.isEmpty || assignedVehicleName.isEmpty) {
        throw FirebaseException(
          plugin: 'cloud_firestore',
          code: 'vehicle-not-assigned',
          message: 'لم يتم تخصيص مركبة لهذا الحساب من المدير.',
        );
      }
      await doc.set({
        'driverId': user.uid,
        'driverEmail': user.email,
        'vehicle': assignedVehicleName,
        'vehicleName': assignedVehicleName,
        'vehicleId': assignedVehicleId,
        'type': type,
        'severity': severity,
        'description': desc.text.trim(),
        'photoUrls': <String>[],
        'photos': 0,
        'status': 'جديد',
        'createdAt': FieldValue.serverTimestamp(),
      });

      final urls = <String>[];
      for (var i = 0; i < photos.length; i++) {
        // استخدم bytes بدل الاعتماد على مسار الملف المؤقت؛ هذا أكثر موثوقية
        // مع صور الكاميرا على أجهزة Android المختلفة.
        final bytes = await photos[i].readAsBytes();
        if (bytes.isEmpty) {
          throw FirebaseException(
            plugin: 'firebase_storage',
            code: 'empty-file',
            message: 'ملف الصورة فارغ أو لم يتم حفظه بشكل صحيح.',
          );
        }
        final ref = FirebaseStorage.instance
            .ref()
            .child('fault_reports')
            .child(doc.id)
            .child('photo_$i.jpg');
        // ارفع الصورة وانتظر اكتمال الرفع فعلياً قبل طلب رابطها.
        // استخدام UploadTask يجعلنا نتأكد أن Firebase Storage أنهى الرفع
        // بدلاً من الانتقال مباشرة إلى getDownloadURL().
        final metadata = SettableMetadata(
          contentType: 'image/jpeg',
          cacheControl: 'public,max-age=86400',
        );
        final task = ref.putData(bytes, metadata);
        final snapshot = await task;
        if (snapshot.state != TaskState.success) {
          throw FirebaseException(
            plugin: 'firebase_storage',
            code: 'upload-failed',
            message: 'لم يكتمل رفع الصورة إلى Firebase Storage.',
          );
        }

        // تحقق أن الكائن موجود فعلاً في Storage.
        await ref.getMetadata();

        String? downloadUrl;
        FirebaseException? lastError;
        for (var attempt = 0; attempt < 6 && downloadUrl == null; attempt++) {
          try {
            downloadUrl = await ref.getDownloadURL();
          } on FirebaseException catch (e) {
            lastError = e;
            if (attempt < 5) {
              await Future<void>.delayed(Duration(milliseconds: 700 * (attempt + 1)));
            }
          }
        }
        if (downloadUrl == null) {
          throw FirebaseException(
            plugin: 'firebase_storage',
            code: lastError?.code ?? 'object-not-found',
            message: lastError?.message ?? 'تم رفع الصورة ولكن تعذر الحصول على رابطها.',
          );
        }
        urls.add(downloadUrl);
      }
      await doc.update({'photoUrls': urls, 'photos': urls.length});
      if (mounted) {
        _msg('تم إرسال البلاغ بنجاح للمشرف');
        Navigator.pop(context);
      }
    } on FirebaseException catch (e) {
      if (doc != null) {
        try { await doc.update({'status': 'تعذر رفع الصور', 'uploadError': e.code}); } catch (_) {}
      }
      final message = switch (e.code) {
        'storage/unauthorized' || 'unauthorized' || 'permission-denied' =>
          'تم حفظ البلاغ لكن رفع الصورة مرفوض من Firebase Storage. انشر قواعد Storage الخاصة بالتطبيق ثم أعد المحاولة.',
        'storage/unauthenticated' || 'unauthenticated' =>
          'انتهت جلسة Firebase أثناء رفع الصورة. سجّل الدخول مرة أخرى.',
        'storage/quota-exceeded' => 'مساحة Firebase Storage ممتلئة أو تجاوزت الحد المسموح.',
        'storage/object-not-found' || 'object-not-found' =>
          'تمت محاولة رفع الصورة لكن Firebase Storage لم يجد الملف بعد. تأكد أن Storage مفعّل وأن قواعد Storage منشورة في Firebase Console.',
        'empty-file' => 'الصورة لم تُحفظ بشكل صحيح. صوّر العطل مرة أخرى.',
        'vehicle-not-assigned' => 'هذا المستخدم غير مربوط بمركبة. اطلب من المدير تخصيص مركبة له.',
        _ => 'تعذر رفع صورة البلاغ: ${e.message ?? e.code}',
      };
      _msg(message);
    } catch (e) {
      _msg('حدث خطأ أثناء الإرسال: $e');
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: const BrandAppBar(title: 'إضافة بلاغ'),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Card(color: brandNavy, child: const Padding(
              padding: EdgeInsets.all(18),
              child: Text('بلاغ عطل جديد\nأدخل التفاصيل وصوّر العطل ثم أرسل البلاغ للمشرف.',
                  style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
            )),
            const SizedBox(height: 18),
            const Label('نوع العطل'),
            DropdownButtonFormField<String>(
              value: type,
              items: ['فرامل','إطارات','محرك','كهرباء','تعليق','تسريب','إضاءة','أخرى']
                  .map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: sending ? null : (v) => setState(() => type = v ?? type),
            ),
            const SizedBox(height: 14),
            const Label('درجة الخطورة'),
            DropdownButtonFormField<String>(
              value: severity,
              items: ['عادي','متوسط','خطير','إيقاف فوري']
                  .map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: sending ? null : (v) => setState(() => severity = v ?? severity),
            ),
            const SizedBox(height: 14),
            const Label('وصف البلاغ'),
            TextField(controller: desc, maxLines: 4, enabled: !sending,
                decoration: const InputDecoration(hintText: 'اكتب تفاصيل العطل...')),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: sending ? null : takePhoto,
              icon: const Icon(Icons.camera_alt),
              label: Text(photos.isEmpty ? 'تصوير العطل (إجباري)' : 'إضافة صورة أخرى (${photos.length})'),
            ),
            if (photos.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: photos.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) => ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(File(photos[i].path), width: 100, height: 100, fit: BoxFit.cover),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 22),
            SizedBox(
              height: 54,
              child: FilledButton.icon(
                onPressed: sending ? null : submit,
                style: FilledButton.styleFrom(backgroundColor: brandRed),
                icon: sending
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.send),
                label: Text(sending ? 'جاري الإرسال...' : 'إرسال البلاغ'),
              ),
            ),
          ],
        ),
      );
}

class SupervisorHome extends StatelessWidget {
  const SupervisorHome({super.key});

  Future<void> logout(BuildContext context) async {
    await FirebaseAuth.instance.signOut();
    if (context.mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: brandNavy,
        foregroundColor: Colors.white,
        title: const Text(
          'لوحة المشرف',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        leading: Padding(
          padding: const EdgeInsets.all(7),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.asset(
              'assets/rawasi_emblem_clean.png',
              fit: BoxFit.cover,
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => logout(context),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('faults').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return ErrorBox(
              error: snapshot.error.toString(),
              onRetry: () {},
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: brandRed),
            );
          }

          final docs = (snapshot.data?.docs ?? [])
              .where((doc) => !isProcessedStatus(statusOf(doc.data())))
              .toList()
            ..sort(
              (a, b) => dateOf(b.data()).compareTo(dateOf(a.data())),
            );

          final urgent = docs
              .where((doc) => doc.data()['severity'] == 'إيقاف فوري')
              .length;
          final newCount = docs
              .where((doc) => statusOf(doc.data()) == 'جديد')
              .length;

          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
            children: [
              const Text(
                'نظرة عامة',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      label: 'البلاغات المفتوحة',
                      value: '${docs.length}',
                      icon: Icons.assignment,
                      color: brandNavy,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: StatCard(
                      label: 'بلاغات جديدة',
                      value: '$newCount',
                      icon: Icons.fiber_new,
                      color: brandRed,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      label: 'إيقاف فوري',
                      value: '$urgent',
                      icon: Icons.priority_high,
                      color: brandRed,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: StatCard(
                      label: 'ملفات المركبات',
                      value: '—',
                      icon: Icons.local_shipping,
                      color: brandNavy,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 52,
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const VehicleListPage(),
                    ),
                  ),
                  icon: const Icon(Icons.local_shipping_outlined),
                  label: const Text(
                    'إدارة ملفات المركبات',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'البلاغات الواردة',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 10),
              if (docs.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(35),
                    child: Center(child: Text('لا توجد بلاغات مفتوحة')),
                  ),
                )
              else
                ...docs.map(
                  (doc) => InkWell(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ReportDetailsPage(
                          report: doc.data(),
                          reportId: doc.id,
                          supervisor: true,
                        ),
                      ),
                    ),
                    child: ReportCard(report: doc.data()),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class ReportDetailsPage extends StatefulWidget {
  final Map<String, dynamic> report;
  final String? reportId;
  final bool supervisor;
  const ReportDetailsPage({super.key, required this.report, this.reportId, this.supervisor = false});
  @override
  State<ReportDetailsPage> createState() => _ReportDetailsPageState();
}

class _ReportDetailsPageState extends State<ReportDetailsPage> {
  bool saving = false;
  Future<void> updateStatus(String status) async {
    if (!widget.supervisor || widget.reportId == null) return;
    String treatment = '';
    double? maintenanceCost;
    XFile? invoicePhoto;

    if (isProcessedStatus(status)) {
      final treatmentController = TextEditingController();
      final costController = TextEditingController();
      final result = await showDialog<Map<String, dynamic>>(
        context: context,
        builder: (dialogContext) {
          XFile? picked;
          return StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
            title: Text(status == 'مغلق' ? 'إغلاق البلاغ' : 'تسجيل المعالجة'),
            content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: treatmentController, maxLines: 4, decoration: const InputDecoration(labelText: 'وصف المعالجة', hintText: 'اكتب ماذا تم عمله لإصلاح العطل...')),
              const SizedBox(height: 14),
              TextField(controller: costController, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'تكلفة الصيانة (ريال)', prefixIcon: Icon(Icons.payments_outlined))),
              const SizedBox(height: 12),
              if (status == 'مغلق') ...[
                SizedBox(width: double.infinity, child: OutlinedButton.icon(
                  onPressed: () async {
                    final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 85);
                    if (x != null) setDialogState(() => picked = x);
                  },
                  icon: const Icon(Icons.camera_alt_outlined),
                  label: Text(picked == null ? 'تصوير فاتورة الصيانة' : 'تم تصوير الفاتورة ✓'),
                )),
                const SizedBox(height: 5),
                const Align(alignment: Alignment.centerRight, child: Text('عند إغلاق البلاغ يجب تصوير الفاتورة.', style: TextStyle(color: muted, fontSize: 11))),
              ],
            ])),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
              FilledButton(onPressed: () {
                final cost = double.tryParse(costController.text.trim());
                if (status == 'مغلق' && picked == null) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يجب تصوير فاتورة الصيانة قبل إغلاق البلاغ')));
                  return;
                }
                Navigator.pop(dialogContext, {'treatment': treatmentController.text.trim(), 'cost': cost, 'invoice': picked});
              }, child: const Text('حفظ')),
            ],
          ));
        },
      );
      treatmentController.dispose();
      costController.dispose();
      if (result == null) return;
      treatment = '${result['treatment'] ?? ''}';
      maintenanceCost = result['cost'] as double?;
      invoicePhoto = result['invoice'] as XFile?;
    }

    setState(() => saving = true);
    try {
      final reportRef = FirebaseFirestore.instance.collection('faults').doc(widget.reportId);
      String? invoiceUrl;
      if (invoicePhoto != null) {
        final bytes = await invoicePhoto!.readAsBytes();
        final storageRef = FirebaseStorage.instance.ref().child('maintenance_invoices/${widget.reportId}/invoice.jpg');
        await storageRef.putData(bytes, SettableMetadata(contentType: 'image/jpeg'));
        invoiceUrl = await storageRef.getDownloadURL();
      }
      final update = <String, dynamic>{
        'status': status,
        'treatment': treatment,
        'maintenanceCost': maintenanceCost,
        'updatedAt': FieldValue.serverTimestamp(),
      };
      if (invoiceUrl != null) update['invoiceUrl'] = invoiceUrl;
      await reportRef.update(update);

      if (isProcessedStatus(status)) {
        final vehicleId = '${widget.report['vehicleId'] ?? ''}';
        if (vehicleId.isNotEmpty) {
          final vehicleRef = FirebaseFirestore.instance.collection('vehicles').doc(vehicleId);
          await FirebaseFirestore.instance.runTransaction((tx) async {
            final snap = await tx.get(vehicleRef);
            if (!snap.exists) return;
            final data = snap.data() ?? <String, dynamic>{};
            final history = List<Map<String, dynamic>>.from((data['history'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)));
            if (!history.any((h) => '${h['id'] ?? ''}' == widget.reportId)) {
              history.add({
                'id': widget.reportId,
                'fault': '${widget.report['type'] ?? 'عطل'}: ${widget.report['description'] ?? ''}',
                'treatment': treatment.isEmpty ? 'تمت المعالجة' : treatment,
                'maintenanceCost': maintenanceCost,
                'invoiceUrl': invoiceUrl,
                'date': Timestamp.now(),
              });
              tx.update(vehicleRef, {'history': history, 'updatedAt': FieldValue.serverTimestamp()});
            }
          });
        }
      }
      if (mounted) setState(() => widget.report['status'] = status);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(status == 'مغلق' ? 'تم إغلاق البلاغ وحفظ تكلفة الصيانة والفاتورة' : 'تم تحديث البلاغ وحفظ المعالجة في ملف المركبة')));
    } on FirebaseException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحديث البلاغ: ${e.message ?? e.code}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ الفاتورة: $e')));
    } finally { if (mounted) setState(() => saving = false); }
  }

  @override
  Widget build(BuildContext c) {
    final urls = List<String>.from(widget.report['photoUrls'] ?? const []);
    final status = '${widget.report['status'] ?? 'جديد'}';
    return Scaffold(
      appBar: const BrandAppBar(title: 'تفاصيل البلاغ'),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${widget.report['type'] ?? 'بلاغ'}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text('المركبة: ${widget.report['vehicle'] ?? ''}'),
            Text('السائق: ${widget.report['driverEmail'] ?? ''}', style: const TextStyle(color: muted)),
            const SizedBox(height: 10),
            Text('الخطورة: ${widget.report['severity'] ?? ''}', style: const TextStyle(color: brandRed, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            const Text('الوصف', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text('${widget.report['description'] ?? ''}', style: const TextStyle(color: muted)),
            const SizedBox(height: 12),
            Text('الحالة: $status', style: const TextStyle(color: brandNavy, fontWeight: FontWeight.w900)),
          ]))),
          if (widget.supervisor) ...[
            const SizedBox(height: 14),
            const Label('تحديث حالة البلاغ'),
            Wrap(spacing: 8, runSpacing: 8, children: ['جديد','قيد المعالجة','تم الإصلاح','مغلق'].map((s) => ChoiceChip(
              label: Text(s), selected: status == s, onSelected: saving ? null : (_) => updateStatus(s), selectedColor: brandRed.withValues(alpha: .18),
            )).toList()),
          ],
          if (widget.report['maintenanceCost'] != null || widget.report['invoiceUrl'] != null) ...[
            const SizedBox(height: 14),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('بيانات تكلفة الصيانة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              if (widget.report['maintenanceCost'] != null) Text('التكلفة: ${widget.report['maintenanceCost']} ريال', style: const TextStyle(fontWeight: FontWeight.w800)),
              if (widget.report['invoiceUrl'] != null) ...[const SizedBox(height: 10), const Text('فاتورة الصيانة', style: TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 8), ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network('${widget.report['invoiceUrl']}', height: 220, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox(height: 100, child: Center(child: Text('تعذر تحميل الفاتورة')))))]
            ]))),
          ],
          const SizedBox(height: 15),
          const Text('صور البلاغ', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          if (urls.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(20), child: Center(child: Text('لا توجد صور مرفوعة بعد'))))
          else
            ...urls.map((u) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.network(u, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox(height: 160, child: Center(child: Text('تعذر تحميل الصورة')))),
              ),
            )),
        ],
      ),
    );
  }
}

class ReportCard extends StatelessWidget {
  final Map<String, dynamic> report;
  const ReportCard({super.key, required this.report});
  @override
  Widget build(BuildContext c) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: brandRed.withValues(alpha: .08),
            child: const Icon(Icons.warning_amber, color: brandRed),
          ),
          title: Text('${report['type'] ?? 'بلاغ'}', style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text('${report['description'] ?? ''}\n${report['vehicle'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: Text('${report['status'] ?? 'جديد'}', style: const TextStyle(color: brandNavy, fontWeight: FontWeight.w800)),
        ),
      );
}

class StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const StatCard({super.key, required this.label, required this.value, required this.icon, required this.color});
  @override
  Widget build(BuildContext c) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Icon(icon, color: color), Text(value, style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: color))]),
    const SizedBox(height: 8), Text(label, style: const TextStyle(color: muted, fontSize: 12)),
  ])));
}

class Label extends StatelessWidget {
  final String text;
  const Label(this.text, {super.key});
  @override
  Widget build(BuildContext c) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900)));
}

class ErrorBox extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;
  const ErrorBox({super.key, required this.error, required this.onRetry});
  @override
  Widget build(BuildContext c) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.cloud_off, color: brandRed, size: 55),
    const SizedBox(height: 12),
    const Text('تعذر تحميل البيانات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    Text(error, textAlign: TextAlign.center, style: const TextStyle(color: muted)),
    const SizedBox(height: 14),
    FilledButton.icon(onPressed: onRetry, style: FilledButton.styleFrom(backgroundColor: brandRed), icon: const Icon(Icons.refresh), label: const Text('إعادة المحاولة')),
  ])));
}

DateTime dateOf(Map<String, dynamic> d) {
  final v = d['createdAt'];
  return v is Timestamp ? v.toDate() : DateTime.fromMillisecondsSinceEpoch(0);
}
