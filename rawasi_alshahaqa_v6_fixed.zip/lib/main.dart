import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'firebase_options.dart';

const navy = Color(0xFF0B1736);
const navy2 = Color(0xFF14264D);
const red = Color(0xFFE53935);
const bg = Color(0xFFF4F6FA);
const textColor = Color(0xFF172033);
const muted = Color(0xFF748096);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const RawasiApp());
}

class RawasiApp extends StatelessWidget {
  const RawasiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'رواسي الشاهقة',
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(seedColor: red),
          cardTheme: CardThemeData(
            elevation: 0,
            color: Colors.white,
            margin: EdgeInsets.zero,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ),
        home: const Directionality(textDirection: TextDirection.rtl, child: Home()),
      );
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(22),
            children: [
              const SizedBox(height: 28),
              Container(
                width: 86,
                height: 86,
                decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(26)),
                child: const Icon(Icons.local_shipping_rounded, color: Colors.white, size: 44),
              ),
              const SizedBox(height: 22),
              const Text('رواسي الشاهقة', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: navy)),
              const SizedBox(height: 7),
              const Text('إدارة أسطول النقل والصيانة', style: TextStyle(fontSize: 16, color: muted)),
              const SizedBox(height: 42),
              RoleCard(
                icon: Icons.drive_eta_rounded,
                title: 'تطبيق السائق',
                subtitle: 'بلاغ الأعطال وتصويرها وتحديد الموقع',
                color: red,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverHome())),
              ),
              const SizedBox(height: 16),
              RoleCard(
                icon: Icons.dashboard_rounded,
                title: 'لوحة المشرف',
                subtitle: 'المركبات والأعطال وسجل الصيانة',
                color: navy,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SupervisorHome())),
              ),
            ],
          ),
        ),
      );
}

class RoleCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;
  const RoleCard({super.key, required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(width: 58, height: 58, decoration: BoxDecoration(color: color.withValues(alpha: .1), borderRadius: BorderRadius.circular(18)), child: Icon(icon, color: color, size: 30)),
                const SizedBox(width: 16),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: textColor)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(color: muted))])),
                const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: muted),
              ],
            ),
          ),
        ),
      );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override State<DriverHome> createState() => _DriverHomeState();
}
class _DriverHomeState extends State<DriverHome> {
  final faults = <Map<String, dynamic>>[];
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تطبيق السائق', style: TextStyle(fontWeight: FontWeight.w800))),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 110),
          children: [
            const VehicleBanner(),
            const SizedBox(height: 22),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('بلاغاتي', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: textColor)), Text('${faults.length} بلاغ', style: const TextStyle(color: muted))]),
            const SizedBox(height: 12),
            if (faults.isEmpty) const EmptyState() else ...faults.map((f) => FaultCard(fault: f)),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: red,
          foregroundColor: Colors.white,
          onPressed: () async {
            final result = await Navigator.push<Map<String, dynamic>>(context, MaterialPageRoute(builder: (_) => const AddFaultPage()));
            if (result != null && mounted) setState(() => faults.insert(0, result));
          },
          icon: const Icon(Icons.camera_alt_rounded),
          label: const Text('تصوير عطل', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
      );
}

class VehicleBanner extends StatelessWidget {
  const VehicleBanner({super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, navy2]), borderRadius: BorderRadius.circular(24)),
        child: const Row(children: [
          Icon(Icons.local_shipping_rounded, color: Colors.white, size: 42),
          SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('المركبة المخصصة لك', style: TextStyle(color: Colors.white70)), SizedBox(height: 4), Text('شاحنة 01 • 1234 أ ب', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)), SizedBox(height: 5), Text('الحالة: جاهزة للعمل', style: TextStyle(color: Colors.white70))])),
          Icon(Icons.verified_rounded, color: Colors.white, size: 28),
        ]),
      );
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 25),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
        child: const Column(children: [Icon(Icons.check_circle_outline_rounded, size: 60, color: Colors.green), SizedBox(height: 14), Text('لا توجد بلاغات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: textColor)), SizedBox(height: 6), Text('إذا لاحظت عطلاً، صوّره وأرسل البلاغ فوراً.', textAlign: TextAlign.center, style: TextStyle(color: muted))]),
      );
}

class FaultCard extends StatelessWidget {
  final Map<String, dynamic> fault;
  const FaultCard({super.key, required this.fault});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: red.withValues(alpha: .1), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.warning_amber_rounded, color: red)),
            const SizedBox(width: 13),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${fault['type']}', style: const TextStyle(fontWeight: FontWeight.w800, color: textColor)), const SizedBox(height: 4), Text('${fault['description']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted))])),
            Pill('${fault['severity']}'),
          ]),
        ),
      );
}

class Pill extends StatelessWidget {
  final String value;
  const Pill(this.value, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(color: (value == 'إيقاف فوري' ? red : navy).withValues(alpha: .1), borderRadius: BorderRadius.circular(20)),
        child: Text(value, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: value == 'إيقاف فوري' ? red : navy)),
      );
}

class AddFaultPage extends StatefulWidget {
  const AddFaultPage({super.key});
  @override State<AddFaultPage> createState() => _AddFaultPageState();
}
class _AddFaultPageState extends State<AddFaultPage> {
  final desc = TextEditingController();
  final picker = ImagePicker();
  final pics = <XFile>[];
  String type = 'فرامل', severity = 'عادي';
  LatLng? location;

  @override
  void dispose() { desc.dispose(); super.dispose(); }
  Future<void> takePhoto() async { final p = await picker.pickImage(source: ImageSource.camera, imageQuality: 82); if (p != null && mounted) setState(() => pics.add(p)); }
  Future<void> chooseLocation() async { final selected = await Navigator.push<LatLng>(context, MaterialPageRoute(builder: (_) => const MapPicker())); if (selected != null && mounted) setState(() => location = selected); }
  void submit() {
    if (pics.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تصوير العطل إجباري قبل الإرسال'))); return; }
    if (desc.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب وصف العطل'))); return; }
    Navigator.pop(context, {'type': type, 'severity': severity, 'description': desc.text.trim(), 'photos': pics.length, 'location': location == null ? null : {'lat': location!.latitude, 'lng': location!.longitude}});
  }
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('بلاغ عطل جديد', style: TextStyle(fontWeight: FontWeight.w800))),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(22)), child: const Row(children: [Icon(Icons.camera_alt_rounded, color: Colors.white, size: 30), SizedBox(width: 12), Expanded(child: Text('صوّر العطل أولاً\nالصورة مطلوبة لإرسال البلاغ', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)))])),
          const SizedBox(height: 18), const Text('نوع العطل', style: TextStyle(fontWeight: FontWeight.w800, color: textColor)), const SizedBox(height: 7),
          DropdownButtonFormField<String>(initialValue: type, items: ['فرامل','إطارات','محرك','كهرباء','تعليق','تسريب','إضاءة','أخرى'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) { if (v != null) setState(() => type = v); }),
          const SizedBox(height: 14), const Text('درجة الخطورة', style: TextStyle(fontWeight: FontWeight.w800, color: textColor)), const SizedBox(height: 7),
          DropdownButtonFormField<String>(initialValue: severity, items: ['عادي','متوسط','خطير','إيقاف فوري'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) { if (v != null) setState(() => severity = v); }),
          const SizedBox(height: 14), const Text('وصف العطل', style: TextStyle(fontWeight: FontWeight.w800, color: textColor)), const SizedBox(height: 7),
          TextField(controller: desc, maxLines: 4, decoration: const InputDecoration(hintText: 'اكتب ما لاحظته بالتفصيل...', filled: true, fillColor: Colors.white)),
          const SizedBox(height: 16),
          FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: red, padding: const EdgeInsets.symmetric(vertical: 16)), onPressed: takePhoto, icon: const Icon(Icons.camera_alt_rounded), label: Text(pics.isEmpty ? 'فتح الكاميرا وتصوير العطل' : 'إضافة صورة أخرى (${pics.length})')),
          if (pics.isNotEmpty) ...[const SizedBox(height: 12), SizedBox(height: 105, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: pics.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) => ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(File(pics[i].path), width: 105, height: 105, fit: BoxFit.cover))))],
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: chooseLocation, icon: const Icon(Icons.location_on), label: Text(location == null ? 'إضافة موقع العطل من خرائط Google' : 'تم تحديد موقع العطل')),
          const SizedBox(height: 20),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 16)), onPressed: submit, child: const Text('إرسال البلاغ', style: TextStyle(fontWeight: FontWeight.w800))),
        ]),
      );
}

class SupervisorHome extends StatelessWidget {
  const SupervisorHome({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('لوحة المشرف', style: TextStyle(fontWeight: FontWeight.w900))),
        body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('faults').orderBy('createdAt', descending: true).snapshots(),
          builder: (context, snapshot) {
            final docs = snapshot.data?.docs ?? [];
            return ListView(padding: const EdgeInsets.all(18), children: [
              const Text('بلاغات الأعطال', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: textColor)),
              const SizedBox(height: 15),
              Row(children: [Expanded(child: Metric(title: 'إجمالي البلاغات', value: '${docs.length}', icon: Icons.warning_amber_rounded, color: red)), const SizedBox(width: 10), Expanded(child: Metric(title: 'حالة الاتصال', value: snapshot.hasError ? 'خطأ' : 'متصل', icon: Icons.cloud_done_rounded, color: navy))]),
              const SizedBox(height: 18),
              if (snapshot.hasError) Text('تعذر قراءة البلاغات: ${snapshot.error}', style: const TextStyle(color: red))
              else if (docs.isEmpty) const EmptyState()
              else ...docs.map((d) { final data = d.data(); return Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: const Icon(Icons.warning_amber_rounded, color: red), title: Text('${data['type'] ?? 'عطل'}', style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${data['description'] ?? ''}'), trailing: Pill('${data['severity'] ?? 'عادي'}'))); }),
            ];
          },
        ),
      );
}

class Metric extends StatelessWidget {
  final String title, value; final IconData icon; final Color color;
  const Metric({super.key, required this.title, required this.value, required this.icon, required this.color});
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [Icon(icon, color: color), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: muted, fontSize: 12)), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: textColor))]))])));
}

class MapPicker extends StatefulWidget { const MapPicker({super.key}); @override State<MapPicker> createState() => _MapPickerState(); }
class _MapPickerState extends State<MapPicker> {
  LatLng selected = const LatLng(28.3838, 36.5550);
  @override void initState() { super.initState(); _getLocation(); }
  Future<void> _getLocation() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return;
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;
      final position = await Geolocator.getCurrentPosition();
      if (mounted) setState(() => selected = LatLng(position.latitude, position.longitude));
    } catch (_) {}
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تحديد موقع العطل', style: TextStyle(fontWeight: FontWeight.w800))),
    body: Stack(children: [GoogleMap(initialCameraPosition: CameraPosition(target: selected, zoom: 14), markers: {Marker(markerId: const MarkerId('fault'), position: selected)}, onTap: (p) => setState(() => selected = p), myLocationEnabled: true, myLocationButtonEnabled: true), Positioned(left: 18, right: 18, bottom: 22, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: red, padding: const EdgeInsets.symmetric(vertical: 16)), onPressed: () => Navigator.pop(context, selected), icon: const Icon(Icons.check), label: const Text('تأكيد الموقع', style: TextStyle(fontWeight: FontWeight.w800))))]),
  );
}
