import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) throw UnsupportedError('Web is not configured.');
    if (defaultTargetPlatform == TargetPlatform.android) return android;
    throw UnsupportedError('Only Android is configured.');
  }
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAZchnbKE7YCrmgRQy8HJAxRGLM_r9MVBI',
    appId: '1:894934127241:android:3fe871233d63123131ac58',
    messagingSenderId: '894934127241',
    projectId: 'rawasi-alshahaqa',
    storageBucket: 'rawasi-alshahaqa.firebasestorage.app',
  );
}
