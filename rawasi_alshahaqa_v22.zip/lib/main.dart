import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'firebase_options.dart';

const brandRed = Color(0xFFE30613);
const brandNavy = Color(0xFF0D1B2A);
const brandBlack = Color(0xFF111111);
const pageBg = Color(0xFFF5F6F8);
const muted = Color(0xFF667085);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  String? error;
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) { error = e.toString(); }
  runApp(RawasiApp(startupError: error));
}

class RawasiApp extends StatelessWidget {
  final String? startupError;
  const RawasiApp({super.key, this.startupError});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'رواسي الشاهقة',
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: pageBg,
      colorScheme: ColorScheme.fromSeed(seedColor: brandRed),
      appBarTheme: const AppBarTheme(backgroundColor: brandNavy, foregroundColor: Colors.white, elevation: 0)),
    home: Directionality(textDirection: TextDirection.rtl, child: LoginPage(startupError: startupError)),
  );
}

class BrandAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title; const BrandAppBar({super.key, required this.title});
  @override Size get preferredSize => const Size.fromHeight(kToolbarHeight);
  @override Widget build(BuildContext context) => AppBar(
    leadingWidth: 58,
    leading: Padding(padding: const EdgeInsets.all(7), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/rawasi_emblem.png', fit: BoxFit.cover))),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
  );
}

class BrandLogo extends StatelessWidget {
  final double width; const BrandLogo({super.key, this.width = 250});
  @override Widget build(BuildContext context) => Image.asset('assets/rawasi_brand_logo_dark.png', width: width, fit: BoxFit.contain);
}

class LoginPage extends StatefulWidget {
  final String? startupError; const LoginPage({super.key, this.startupError});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false; bool obscure = true;
  @override void dispose(){ email.dispose(); password.dispose(); super.dispose(); }

  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) { _msg('أدخل البريد الإلكتروني وكلمة المرور'); return; }
    setState(() => loading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => RolePage(email: email.text.trim())));
    } on FirebaseAuthException catch(e) { _msg(_authMessage(e.code)); }
    catch(e) { _msg('تعذر تسجيل الدخول: $e'); }
    finally { if(mounted) setState(() => loading = false); }
  }
  Future<void> register() async {
    if (email.text.trim().isEmpty || password.text.length < 6) { _msg('استخدم بريدًا صحيحًا وكلمة مرور من 6 أحرف على الأقل'); return; }
    setState(() => loading = true);
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
      if (!mounted) return;
      _msg('تم إنشاء الحساب. اختر نوع الاستخدام الآن.');
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => RolePage(email: email.text.trim())));
    } on FirebaseAuthException catch(e) { _msg(_authMessage(e.code)); }
    catch(e) { _msg('تعذر إنشاء الحساب: $e'); }
    finally { if(mounted) setState(() => loading = false); }
  }
  String _authMessage(String code) => switch(code) {
    'invalid-credential' || 'wrong-password' || 'user-not-found' => 'البريد أو كلمة المرور غير صحيحة',
    'email-already-in-use' => 'البريد مستخدم مسبقًا',
    'invalid-email' => 'البريد الإلكتروني غير صحيح',
    'weak-password' => 'كلمة المرور ضعيفة',
    'network-request-failed' => 'تحقق من اتصال الإنترنت',
    _ => 'تعذر تسجيل الدخول: $code'
  };
  void _msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(22, 35, 22, 30), children: [
      Center(child: BrandLogo(width: 275)), const SizedBox(height: 18),
      const Center(child: Text('نظام إدارة أسطول النقل والصيانة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
      const SizedBox(height: 28),
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        const Align(alignment: Alignment.centerRight, child: Text('تسجيل الدخول', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900))),
        const SizedBox(height: 18),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined))),
        const SizedBox(height: 13),
        TextField(controller: password, obscureText: obscure, decoration: InputDecoration(labelText: 'كلمة المرور', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: ()=>setState(()=>obscure=!obscure), icon: Icon(obscure?Icons.visibility_outlined:Icons.visibility_off_outlined)))),
        const SizedBox(height: 20),
        SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: loading?null:login, style: FilledButton.styleFrom(backgroundColor: brandRed), child: loading?const CircularProgressIndicator(color: Colors.white):const Text('دخول', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)))),
        const SizedBox(height: 9),
        TextButton(onPressed: loading?null:register, child: const Text('إنشاء حساب جديد')),
      ]))),
      if(widget.startupError != null) Padding(padding: const EdgeInsets.only(top: 15), child: Text('تعذر تهيئة Firebase: ${widget.startupError}', textAlign: TextAlign.center, style: const TextStyle(color: brandRed))),
    ])),
  );
}

class RolePage extends StatelessWidget {
  final String email; const RolePage({super.key, required this.email});
  Future<void> logout(BuildContext context) async { await FirebaseAuth.instance.signOut(); if(context.mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder:(_)=>const LoginPage()), (_)=>false); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: BrandAppBar(title: 'رواسي الشاهقة'),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Card(color: brandNavy, child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('مرحباً بك', style: TextStyle(color: Colors.white70)), const SizedBox(height: 5), Text(email, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
      ]))), const SizedBox(height: 22),
      const Text('اختر الواجهة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const SizedBox(height: 12),
      RoleButton(icon: Icons.local_shipping_rounded, title:'تطبيق السائق', subtitle:'إضافة بلاغ وتصوير العطل', color:brandRed, onTap:()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>const DriverHome()))),
      const SizedBox(height:12), RoleButton(icon:Icons.dashboard_rounded, title:'لوحة المشرف', subtitle:'استلام البلاغات ومتابعتها', color:brandNavy, onTap:()=>Navigator.push(context, MaterialPageRoute(builder:(_)=>const SupervisorHome()))),
      const SizedBox(height:20), OutlinedButton.icon(onPressed:()=>logout(context), icon:const Icon(Icons.logout), label:const Text('تسجيل الخروج')),
    ],
  ));
}
class RoleButton extends StatelessWidget { final IconData icon; final String title,subtitle; final Color color; final VoidCallback onTap; const RoleButton({super.key,required this.icon,required this.title,required this.subtitle,required this.color,required this.onTap});
  @override Widget build(BuildContext c)=>Card(child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(16),child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[Container(width:58,height:58,decoration:BoxDecoration(color:color.withValues(alpha:.1),borderRadius:BorderRadius.circular(15)),child:Icon(icon,color:color,size:30)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text(subtitle,style:const TextStyle(color:muted))])),Icon(Icons.arrow_back_ios_new,size:16,color:color)])))); }

class DriverHome extends StatelessWidget { const DriverHome({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:const BrandAppBar(title:'تطبيق السائق'),body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirebaseFirestore.instance.collection('faults').where('driverId',isEqualTo:FirebaseAuth.instance.currentUser?.uid).snapshots(),builder:(c,s){if(s.hasError)return ErrorBox(error:s.error.toString(),onRetry:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>const DriverHome())));final docs=[...(s.data?.docs??[])];docs.sort((a,b)=>dateOf(b.data()).compareTo(dateOf(a.data())));return ListView(padding:const EdgeInsets.fromLTRB(18,18,18,110),children:[Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:brandNavy,borderRadius:BorderRadius.circular(22)),child:const Row(children:[Icon(Icons.local_shipping_rounded,color:Colors.white,size:34),SizedBox(width:14),Expanded(child:Text('المركبة المخصصة لك\nشاحنة 01 • 1234 أ ب',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:17)))])),const SizedBox(height:24),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('بلاغاتي',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),Text('${docs.length} بلاغ',style:const TextStyle(color:muted))]),const SizedBox(height:10),if(docs.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(35),child:Center(child:Text('لا توجد بلاغات'))))else...docs.map((d)=>ReportCard(report:d.data()))];}),),floatingActionButton:FloatingActionButton.extended(backgroundColor:brandRed,foregroundColor:Colors.white,onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AddReportPage())),icon:const Icon(Icons.assignment_add),label:const Text('إضافة بلاغ'))); }

class AddReportPage extends StatefulWidget { const AddReportPage({super.key}); @override State<AddReportPage> createState()=>_AddReportPageState(); }
class _AddReportPageState extends State<AddReportPage>{ final desc=TextEditingController(); final picker=ImagePicker(); final photos=<XFile>[]; String type='فرامل',severity='عادي'; bool sending=false;
 @override void dispose(){desc.dispose();super.dispose();}
 Future<void> takePhoto() async {try{final p=await picker.pickImage(source:ImageSource.camera,imageQuality:82);if(p!=null&&mounted)setState(()=>photos.add(p));}catch(e){if(mounted)_msg('تعذر فتح الكاميرا: $e');}}
 void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
 Future<void> submit() async {if(photos.isEmpty){_msg('يجب تصوير العطل قبل إرسال البلاغ');return;}if(desc.text.trim().isEmpty){_msg('اكتب وصف العطل أولاً');return;}final user=FirebaseAuth.instance.currentUser;if(user==null){_msg('انتهت جلسة الدخول، سجل الدخول مرة أخرى');return;}setState(()=>sending=true);try{final doc=FirebaseFirestore.instance.collection('faults').doc();final urls=<String>[];for(var i=0;i<photos.length;i++){final ref=FirebaseStorage.instance.ref('fault_reports/${doc.id}/photo_$i.jpg');await ref.putFile(File(photos[i].path),SettableMetadata(contentType:'image/jpeg'));urls.add(await ref.getDownloadURL());}await doc.set({'driverId':user.uid,'driverEmail':user.email,'vehicle':'شاحنة 01 • 1234 أ ب','type':type,'severity':severity,'description':desc.text.trim(),'photoUrls':urls,'photos':urls.length,'status':'جديد','createdAt':FieldValue.serverTimestamp()});if(mounted){_msg('تم إرسال البلاغ بنجاح للمشرف');Navigator.pop(context);}}on FirebaseException catch(e){_msg('تعذر إرسال البلاغ: ${e.message??e.code}');}catch(e){_msg('حدث خطأ أثناء الإرسال: $e');}finally{if(mounted)setState(()=>sending=false);}}
 @override Widget build(BuildContext c)=>Scaffold(appBar:const BrandAppBar(title:'إضافة بلاغ'),body:ListView(padding:const EdgeInsets.all(18),children:[Card(color:brandNavy,child:const Padding(padding:EdgeInsets.all(18),child:Text('بلاغ عطل جديد\nأدخل التفاصيل وصوّر العطل ثم أرسل البلاغ للمشرف.',style:TextStyle(color:Colors.white,fontSize:17,fontWeight:FontWeight.w900)))),const SizedBox(height:18),const Label('نوع العطل'),DropdownButtonFormField<String>(initialValue:type,items:['فرامل','إطارات','محرك','كهرباء','تعليق','تسريب','إضاءة','أخرى'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:sending?null:(v)=>setState(()=>type=v??type)),const SizedBox(height:14),const Label('درجة الخطورة'),DropdownButtonFormField<String>(initialValue:severity,items:['عادي','متوسط','خطير','إيقاف فوري'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:sending?null:(v)=>setState(()=>severity=v??severity)),const SizedBox(height:14),const Label('وصف البلاغ'),TextField(controller:desc,maxLines:4,enabled:!sending,decoration:const InputDecoration(hintText:'اكتب تفاصيل العطل...')),const SizedBox(height:16),OutlinedButton.icon(onPressed:sending?null:takePhoto,icon:const Icon(Icons.camera_alt),label:Text(photos.isEmpty?'تصوير العطل (إجباري)':'إضافة صورة أخرى (${photos.length})')),if(photos.isNotEmpty)Padding(padding:const EdgeInsets.only(top:10),child:SizedBox(height:100,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:photos.length,separatorBuilder:(_,__)=>const SizedBox(width:8),itemBuilder:(_,i)=>ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.file(File(photos[i].path),width:100,height:100,fit:BoxFit.cover))))),const SizedBox(height:22),SizedBox(height:54,child:FilledButton.icon(onPressed:sending?null:submit,style:FilledButton.styleFrom(backgroundColor:brandRed),icon:sending?const SizedBox(width:18,height:18,child:CircularProgressIndicator(color:Colors.white,strokeWidth:2)):const Icon(Icons.send),label:Text(sending?'جاري الإرسال...':'إرسال البلاغ')))])); }

class SupervisorHome extends StatelessWidget { const SupervisorHome({super.key});
 @override Widget build(BuildContext c)=>Scaffold(appBar:const BrandAppBar(title:'لوحة المشرف'),body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirebaseFirestore.instance.collection('faults').snapshots(),builder:(ctx,s){if(s.hasError)return ErrorBox(error:s.error.toString(),onRetry:()=>Navigator.pushReplacement(ctx,MaterialPageRoute(builder:(_)=>const SupervisorHome())));if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator(color:brandRed));final docs=[...(s.data?.docs??[])];docs.sort((a,b)=>dateOf(b.data()).compareTo(dateOf(a.data())));final urgent=docs.where((d)=>d.data()['severity']=='إيقاف فوري').length;return ListView(padding:const EdgeInsets.all(18),children:[const Text('نظرة عامة',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:12),Row(children:[Expanded(child:StatCard(label:'إجمالي البلاغات',value:'${docs.length}',icon:Icons.assignment,color:brandNavy)),const SizedBox(width:10),Expanded(child:StatCard(label:'إيقاف فوري',value:'$urgent',icon:Icons.priority_high,color:brandRed))]),const SizedBox(height:24),const Text('البلاغات الواردة',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:10),if(docs.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(35),child:Center(child:Text('لا توجد بلاغات حتى الآن'))))else...docs.map((d)=>InkWell(onTap:()=>Navigator.push(ctx,MaterialPageRoute(builder:(_)=>ReportDetailsPage(report:d.data()))),child:ReportCard(report:d.data())))];})); }
}

class ReportDetailsPage extends StatelessWidget { final Map<String,dynamic> report; const ReportDetailsPage({super.key,required this.report});
 @override Widget build(BuildContext c){final urls=List<String>.from(report['photoUrls']??const[]);return Scaffold(appBar:const BrandAppBar(title:'تفاصيل البلاغ'),body:ListView(padding:const EdgeInsets.all(18),children:[Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${report['type']??'بلاغ'}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('المركبة: ${report['vehicle']??''}'),Text('السائق: ${report['driverEmail']??''}',style:const TextStyle(color:muted)),const SizedBox(height:10),Text('الخطورة: ${report['severity']??''}',style:const TextStyle(color:brandRed,fontWeight:FontWeight.w900)),const SizedBox(height:12),const Text('الوصف',style:TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:5),Text('${report['description']??''}',style:const TextStyle(color:muted)),const SizedBox(height:12),Text('الحالة: ${report['status']??'جديد'}',style:const TextStyle(color:brandNavy,fontWeight:FontWeight.w900))]))),const SizedBox(height:15),const Text('صور البلاغ',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),if(urls.isEmpty)const Text('لا توجد صور')else...urls.map((u)=>Padding(padding:const EdgeInsets.only(bottom:12),child:ClipRRect(borderRadius:BorderRadius.circular(15),child:Image.network(u,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const SizedBox(height:120,child:Center(child:Text('تعذر تحميل الصورة')))))))]);}
}

class ReportCard extends StatelessWidget{final Map<String,dynamic> report;const ReportCard({super.key,required this.report});@override Widget build(BuildContext c)=>Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(leading:CircleAvatar(backgroundColor:brandRed.withValues(alpha:.08),child:const Icon(Icons.warning_amber,color:brandRed)),title:Text('${report['type']??'بلاغ'}',style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('${report['description']??''}\n${report['vehicle']??''}',maxLines:2,overflow:TextOverflow.ellipsis),trailing:Text('${report['status']??'جديد'}',style:const TextStyle(color:brandNavy,fontWeight:FontWeight.w800))));}
class StatCard extends StatelessWidget{final String label,value;final IconData icon;final Color color;const StatCard({super.key,required this.label,required this.value,required this.icon,required this.color});@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Icon(icon,color:color),Text(value,style:TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:color))]),const SizedBox(height:8),Text(label,style:const TextStyle(color:muted,fontSize:12))])));}
class Label extends StatelessWidget{final String text;const Label(this.text,{super.key});@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.only(bottom:7),child:Text(text,style:const TextStyle(fontWeight:FontWeight.w900)));}
class ErrorBox extends StatelessWidget{final String error;final VoidCallback onRetry;const ErrorBox({super.key,required this.error,required this.onRetry});@override Widget build(BuildContext c)=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.cloud_off,color:brandRed,size:55),const SizedBox(height:12),const Text('تعذر تحميل البلاغات',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(error,textAlign:TextAlign.center,style:const TextStyle(color:muted)),const SizedBox(height:14),FilledButton.icon(onPressed:onRetry,style:FilledButton.styleFrom(backgroundColor:brandRed),icon:const Icon(Icons.refresh),label:const Text('إعادة المحاولة'))])));}
DateTime dateOf(Map<String,dynamic> d){final v=d['createdAt'];return v is Timestamp?v.toDate():DateTime.fromMillisecondsSinceEpoch(0);}
