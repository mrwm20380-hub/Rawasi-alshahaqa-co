# Rawasi Alshahaqa V40

- Professionalized the login/branding graphics using the full company lockup.
- Full company name: رواسي الشاهقة للخدمات اللوجستية.
- Rebuilt Android launcher icon from the Rawasi brand; no Flutter icon resources are used.
- Adaptive Android launcher icon uses Rawasi foreground and navy background.
- Five built-in vehicle 360-degree views remain available inside every vehicle file.
- Persistent Firebase login remains enabled; closing the app does not sign the user out.
- Existing driver/vehicle assignment, maintenance cost, invoice photo, users, vehicles, and report features are preserved.
