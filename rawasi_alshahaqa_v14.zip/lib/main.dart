import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'firebase_options.dart';

const brandRed = Color(0xFFE30613);
const brandNavy = Color(0xFF0D1B2A);
const brandBlack = Color(0xFF111111);
const pageBg = Color(0xFFF5F6F8);
const muted = Color(0xFF667085);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const RawasiApp());
}

class RawasiApp extends StatelessWidget {
  const RawasiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رواسي الشاهقة',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pageBg,
        colorScheme: ColorScheme.fromSeed(seedColor: brandRed),
        appBarTheme: const AppBarTheme(
          backgroundColor: brandNavy,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE4E7EC))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: brandRed, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        ),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomePage()),
    );
  }
}

class BrandLogo extends StatelessWidget {
  final double width;
  final bool darkSurface;
  const BrandLogo({super.key, this.width = 190, this.darkSurface = false});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(8),
    decoration: BoxDecoration(
      color: darkSurface ? Colors.white : Colors.white,
      borderRadius: BorderRadius.circular(18),
      boxShadow: const [BoxShadow(color: Color(0x18000000), blurRadius: 16, offset: Offset(0, 6))],
    ),
    child: Image.asset('assets/rawasi_logo.png', width: width, fit: BoxFit.contain),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [brandNavy, Color(0xFF15283A), pageBg], stops: [0, .43, .43]),
      ),
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 26, 20, 30),
          children: [
            Center(child: BrandLogo(width: 205, darkSurface: true)),
            const SizedBox(height: 22),
            const Center(child: Text('إدارة أسطول النقل والصيانة', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700))),
            const SizedBox(height: 7),
            const Center(child: Text('الخدمات اللوجستية', style: TextStyle(color: Colors.white70, fontSize: 14))),
            const SizedBox(height: 38),
            RoleCard(
              icon: Icons.local_shipping_rounded,
              title: 'تطبيق السائق',
              subtitle: 'إضافة بلاغ أعطال وتصويرها',
              accent: brandRed,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DriverHome())),
            ),
            const SizedBox(height: 14),
            RoleCard(
              icon: Icons.dashboard_rounded,
              title: 'لوحة المشرف',
              subtitle: 'متابعة البلاغات وحالة المركبات',
              accent: brandNavy,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SupervisorHome())),
            ),
          ],
        ),
      ),
    ),
  );
}

class RoleCard extends StatelessWidget {
  final IconData icon; final String title, subtitle; final Color accent; final VoidCallback onTap;
  const RoleCard({super.key, required this.icon, required this.title, required this.subtitle, required this.accent, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white,
    margin: EdgeInsets.zero,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    child: InkWell(
      borderRadius: BorderRadius.circular(20), onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(children: [
          Container(width: 58, height: 58, decoration: BoxDecoration(color: accent.withValues(alpha: .10), borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: accent, size: 30)),
          const SizedBox(width: 15),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: brandBlack, fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5), Text(subtitle, style: const TextStyle(color: muted, fontSize: 13)),
          ])),
          Icon(Icons.arrow_back_ios_new_rounded, size: 16, color: accent),
        ]),
      ),
    ),
  );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override State<DriverHome> createState() => _DriverHomeState();
}
class _DriverHomeState extends State<DriverHome> {
  final reports = <Map<String, dynamic>>[];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تطبيق السائق', style: TextStyle(fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 110), children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: brandNavy, borderRadius: BorderRadius.circular(22)),
        child: Row(children: [
          Container(width: 56, height: 56, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .10), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.local_shipping_rounded, color: Colors.white, size: 31)),
          const SizedBox(width: 14),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('المركبة المخصصة لك', style: TextStyle(color: Colors.white70, fontSize: 13)),
            SizedBox(height: 4), Text('شاحنة 01 • 1234 أ ب', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
            SizedBox(height: 4), Text('جاهزة للعمل', style: TextStyle(color: Color(0xFFE9EEF4), fontSize: 12)),
          ])),
        ]),
      ),
      const SizedBox(height: 24),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('بلاغاتي', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: brandBlack)),
        Text('${reports.length} بلاغ', style: const TextStyle(color: muted, fontWeight: FontWeight.w700)),
      ]),
      const SizedBox(height: 12),
      if (reports.isEmpty) const EmptyReports()
      else ...reports.map((r) => ReportCard(report: r)),
    ]),
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor: brandRed, foregroundColor: Colors.white,
      onPressed: () async {
        final result = await Navigator.push<Map<String, dynamic>>(context, MaterialPageRoute(builder: (_) => const AddReportPage()));
        if (result != null && mounted) setState(() => reports.insert(0, result));
      },
      icon: const Icon(Icons.add_a_photo_rounded),
      label: const Text('إضافة بلاغ', style: TextStyle(fontWeight: FontWeight.w900)),
    ),
  );
}

class EmptyReports extends StatelessWidget {
  const EmptyReports({super.key});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white,
    child: Padding(padding: const EdgeInsets.symmetric(vertical: 48, horizontal: 24), child: Column(children: [
      Container(width: 72, height: 72, decoration: BoxDecoration(color: brandNavy.withValues(alpha: .07), shape: BoxShape.circle), child: const Icon(Icons.assignment_outlined, color: brandNavy, size: 37)),
      const SizedBox(height: 15),
      const Text('لا توجد بلاغات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 7),
      const Text('عند ملاحظة أي عطل، أضف بلاغاً وصوّر العطل لإرساله للمشرف.', textAlign: TextAlign.center, style: TextStyle(color: muted, height: 1.5)),
    ])),
  );
}

class ReportCard extends StatelessWidget {
  final Map<String, dynamic> report;
  const ReportCard({super.key, required this.report});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: Padding(padding: const EdgeInsets.all(15), child: Row(children: [
      Container(width: 50, height: 50, decoration: BoxDecoration(color: brandRed.withValues(alpha: .08), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.warning_amber_rounded, color: brandRed)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${report['type']}', style: const TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 4), Text('${report['description']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 13)),
        const SizedBox(height: 5), Text('${report['photos']} صورة • ${report['status']}', style: const TextStyle(color: brandNavy, fontSize: 11, fontWeight: FontWeight.w700)),
      ])),
    ])),
  );
}

class AddReportPage extends StatefulWidget {
  const AddReportPage({super.key});
  @override State<AddReportPage> createState() => _AddReportPageState();
}
class _AddReportPageState extends State<AddReportPage> {
  final description = TextEditingController();
  final picker = ImagePicker();
  final photos = <XFile>[];
  String type = 'فرامل';
  String severity = 'عادي';
  bool sending = false;

  @override void dispose() { description.dispose(); super.dispose(); }

  Future<void> takePhoto() async {
    final photo = await picker.pickImage(source: ImageSource.camera, imageQuality: 82);
    if (photo != null && mounted) setState(() => photos.add(photo));
  }

  void submit() {
    if (photos.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يجب تصوير العطل قبل إرسال البلاغ')));
      return;
    }
    if (description.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب وصف العطل أولاً')));
      return;
    }
    setState(() => sending = true);
    Navigator.pop(context, {'type': type, 'severity': severity, 'description': description.text.trim(), 'photos': photos.length, 'status': 'جديد'});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إضافة بلاغ', style: TextStyle(fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 30), children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: brandNavy, borderRadius: BorderRadius.circular(22)),
        child: const Row(children: [
          Icon(Icons.assignment_add, color: Colors.white, size: 31), SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('بلاغ عطل جديد', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
            SizedBox(height: 5), Text('أدخل التفاصيل ثم صوّر العطل لإرسال البلاغ.', style: TextStyle(color: Colors.white70, fontSize: 12)),
          ])),
        ]),
      ),
      const SizedBox(height: 22),
      const SectionLabel('نوع العطل'),
      const SizedBox(height: 7),
      DropdownButtonFormField<String>(
        initialValue: type,
        items: ['فرامل','إطارات','محرك','كهرباء','تعليق','تسريب','إضاءة','أخرى'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) { if (v != null) setState(() => type = v); },
      ),
      const SizedBox(height: 16),
      const SectionLabel('درجة الخطورة'),
      const SizedBox(height: 7),
      DropdownButtonFormField<String>(
        initialValue: severity,
        items: ['عادي','متوسط','خطير','إيقاف فوري'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) { if (v != null) setState(() => severity = v); },
      ),
      const SizedBox(height: 16),
      const SectionLabel('وصف البلاغ'),
      const SizedBox(height: 7),
      TextField(controller: description, maxLines: 4, textInputAction: TextInputAction.newline, decoration: const InputDecoration(hintText: 'اكتب ما لاحظته بالتفصيل...')),
      const SizedBox(height: 18),
      Row(children: [
        const Expanded(child: SectionLabel('صور العطل')),
        if (photos.isEmpty) const Text('إجباري', style: TextStyle(color: brandRed, fontWeight: FontWeight.w900, fontSize: 12)),
      ]),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        style: OutlinedButton.styleFrom(foregroundColor: brandRed, side: const BorderSide(color: brandRed), padding: const EdgeInsets.symmetric(vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        onPressed: takePhoto,
        icon: const Icon(Icons.camera_alt_rounded),
        label: Text(photos.isEmpty ? 'تصوير العطل' : 'إضافة صورة أخرى (${photos.length})', style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
      if (photos.isNotEmpty) ...[
        const SizedBox(height: 12),
        SizedBox(height: 105, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: photos.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) => ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(File(photos[i].path), width: 105, height: 105, fit: BoxFit.cover)))),
      ],
      const SizedBox(height: 24),
      SizedBox(height: 54, child: FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: brandRed, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        onPressed: sending ? null : submit,
        icon: const Icon(Icons.send_rounded),
        label: const Text('إرسال البلاغ', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
      )),
    ]),
  );
}

class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});
  @override Widget build(BuildContext context) => Text(text, style: const TextStyle(color: brandBlack, fontWeight: FontWeight.w900, fontSize: 14));
}

class SupervisorHome extends StatelessWidget {
  const SupervisorHome({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('لوحة المشرف', style: TextStyle(fontWeight: FontWeight.w900))),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('faults').orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snapshot) {
        final docs = snapshot.data?.docs ?? [];
        final urgent = docs.where((d) => d.data()['severity'] == 'إيقاف فوري').length;
        return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 30), children: [
          const Text('نظرة عامة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: brandBlack)),
          const SizedBox(height: 13),
          Row(children: [
            Expanded(child: StatCard(label: 'إجمالي البلاغات', value: '${docs.length}', icon: Icons.assignment_outlined, color: brandNavy)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(label: 'عاجل', value: '$urgent', icon: Icons.priority_high_rounded, color: brandRed)),
          ]),
          const SizedBox(height: 25),
          const Text('البلاغات الواردة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: brandBlack)),
          const SizedBox(height: 12),
          if (docs.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(36), child: Center(child: Text('لا توجد بلاغات حتى الآن', style: TextStyle(color: muted)))))
          else ...docs.map((doc) => ReportCard(report: doc.data())),
        ]);
      },
    ),
  );
}

class StatCard extends StatelessWidget {
  final String label, value; final IconData icon; final Color color;
  const StatCard({super.key, required this.label, required this.value, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Container(width: 40, height: 40, decoration: BoxDecoration(color: color.withValues(alpha: .09), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: color)), Text(value, style: TextStyle(color: color, fontSize: 25, fontWeight: FontWeight.w900))]),
    const SizedBox(height: 10), Text(label, style: const TextStyle(color: muted, fontSize: 12, fontWeight: FontWeight.w700)),
  ])));
}
