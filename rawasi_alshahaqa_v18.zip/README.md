# رواسي الشاهقة - نسخة Firebase

تم ربط التطبيق مبدئياً بـ Firebase: تسجيل دخول مجهول، Firestore للبلاغات، وCloud Storage لصور البلاغات.

قبل التشغيل لأول مرة في Firebase Console:
1. Authentication > Sign-in method > فعّل Anonymous.
2. Firestore Database > Rules: استخدم `firestore.rules`.
3. Storage > Rules: استخدم `storage.rules`.

عند إرسال البلاغ: تُرفع الصور إلى Storage ثم يُنشأ سجل البلاغ في مجموعة `faults`. لوحة المشرف تقرأ البلاغات مباشرة وتعرض الصور عند فتح البلاغ.
