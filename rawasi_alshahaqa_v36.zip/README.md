Rawasi Alshahaqa V35

V35: forces the Android launcher icon to use the Rawasi logo via drawable-nodpi and removes Flutter-generated launcher resources.
