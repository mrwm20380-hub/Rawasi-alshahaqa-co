# Rawasi Alshahaqa V36
- Static built-in vehicle 360° viewer: 5 fixed AI-generated truck/trailer angles bundled in the APK.
- No vehicle 360 image upload is required.
- Improved transparent Rawasi logo asset.
- Android launcher icon forced to Rawasi branding; Flutter launcher icons are removed during CI generation.
- Vehicle files show the built-in 360 viewer.
- Build workflow extracts rawasi_alshahaqa_v36.zip.
